#include <stdio.h>

int main() {
    int i = 5, j = 7;

    float result = (float) i / j;

    printf("5 / 7 = %.7f", result);

    return 0;
}